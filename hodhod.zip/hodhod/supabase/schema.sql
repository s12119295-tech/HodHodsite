-- ============================================================
-- هدهد — اسکیمای پایگاه‌داده سوپابیس
-- این فایل را در Supabase Dashboard > SQL Editor اجرا کنید
-- ============================================================

-- پروفایل کاربران
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  username text unique not null,
  phone text,
  created_at timestamptz default now()
);

-- روم‌ها
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  invite_code text unique not null,
  created_by uuid references public.profiles(id),
  created_at timestamptz default now()
);

-- اعضای روم
create table if not exists public.room_members (
  room_id uuid references public.rooms(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  joined_at timestamptz default now(),
  primary key (room_id, user_id)
);

-- پیام‌ها
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid references public.rooms(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('text','image','video','audio','voice')),
  content text not null,
  created_at timestamptz default now()
);

create index if not exists messages_room_idx on public.messages (room_id, created_at);

-- فعال‌سازی رکورد سطر (RLS)
alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.messages enable row level security;

-- پروفایل‌ها: هرکسی می‌تواند پروفایل‌ها را ببیند، فقط خودش می‌تواند بسازد/ویرایش کند
create policy "profiles are viewable by everyone" on public.profiles
  for select using (true);
create policy "users can insert own profile" on public.profiles
  for insert with check (auth.uid() = id);
create policy "users can update own profile" on public.profiles
  for update using (auth.uid() = id);

-- روم‌ها: کاربر لاگین‌کرده می‌تواند بسازد؛ با کد دعوت قابل مشاهده است
create policy "authenticated can create rooms" on public.rooms
  for insert with check (auth.uid() = created_by);
create policy "rooms viewable by authenticated" on public.rooms
  for select using (auth.role() = 'authenticated');

-- عضویت روم
create policy "members can view memberships of their rooms" on public.room_members
  for select using (
    user_id = auth.uid() or
    room_id in (select room_id from public.room_members where user_id = auth.uid())
  );
create policy "users can join rooms" on public.room_members
  for insert with check (user_id = auth.uid());

-- پیام‌ها: فقط اعضای روم می‌بینند و می‌فرستند
create policy "members can read messages" on public.messages
  for select using (
    room_id in (select room_id from public.room_members where user_id = auth.uid())
  );
create policy "members can send messages" on public.messages
  for insert with check (
    user_id = auth.uid() and
    room_id in (select room_id from public.room_members where user_id = auth.uid())
  );

-- ============================================================
-- Storage: باکت مدیا برای عکس/ویدیو/صدا/آهنگ
-- این بخش را هم در SQL Editor اجرا کنید
-- ============================================================
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

create policy "public can read media" on storage.objects
  for select using (bucket_id = 'media');
create policy "authenticated can upload media" on storage.objects
  for insert with check (bucket_id = 'media' and auth.role() = 'authenticated');

-- ============================================================
-- Realtime: پیام‌ها باید در انتشار realtime باشند
-- ============================================================
alter publication supabase_realtime add table public.messages;
